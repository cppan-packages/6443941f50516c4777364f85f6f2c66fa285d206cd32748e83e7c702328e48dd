#ifndef OPENCV_REG_PRECOMP_H__
#define OPENCV_REG_PRECOMP_H__


#endif
